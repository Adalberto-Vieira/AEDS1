#ifndef ESTATISTICA_H
#define ESTATISTICA_H
#include <Math.h>
#include <stdio.h>
#include <stdio.h>

double cauchy(double x);
double gumbel(double x, double y, double b);
double laplace(double x, double y, double b);
#endif
