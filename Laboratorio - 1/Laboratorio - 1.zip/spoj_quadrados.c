#include <stdio.h>

int main(void) {
	int n;
	fscanf(stdin,"%i",&n);
	fprintf(stdout,"%i\n",(n*n));
	return 0;
}
