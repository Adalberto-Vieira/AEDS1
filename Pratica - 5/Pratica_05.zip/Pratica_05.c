#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void printNumbers(unsigned int n){


}

int main(){
    /* Localiza o codigo para imprimir caracteres especiais. */
    setlocale(LC_ALL, "");
    int op,number,max=-1,min;
    int result=0;
    unsigned int n;
    printf("Digite o n�mero do exerc�cio desejado (0 para encerrar): ");
    scanf("%d",&op);
    while(op!=0){
        switch(op){
            case 1:
                printf("\nDigite o n�mero correspondente ao valor n :");
                scanf("%d", &n);
                for(int i=1; i<=n;i++){
                    printf("%d ",i);
                }
                fflush(stdin);
                printf("\nDigite algo para continuar");
                getchar();
                system("@cls||clear");
                break;
            case 2:
                printf("\nDigite o n�mero correspondente ao valor n :");
                scanf("%d", &n);
                for(int i=n; i>=0;i--){
                    printf("%d ",i);
                }
                fflush(stdin);
                printf("\nDigite algo para continuar");
                getchar();
                system("@cls||clear");
                break;
            case 3:
                printf("\nDigite o n�mero correspondente ao valor n :");
                scanf("%d", &n);
                for(int i=1; i<=n;i+=2){
                    printf("%d ",i);
                }
                fflush(stdin);
                printf("\nDigite algo para continuar");
                getchar();
                system("@cls||clear");
                break;
            case 4:
                printf("\nDigite o n�mero correspondente ao valor n :");
                scanf("%d", &n);
                for(int i=0; i<=n;i+=2){
                   result+=i;
                }
                printf("%d ",result);
                fflush(stdin);
                printf("\nDigite algo para continuar");
                getchar();
                system("@cls||clear");
                result=0;
                break;
            case 5:
                for(int i=0; i<10;i++){
                    printf("\nDigite o n�mero correspondente ao valor n :");
                    scanf("%d", &n);
                    result+=n;
                }
                printf("%d ",result/10);
                fflush(stdin);
                printf("\nDigite algo para continuar");
                getchar();
                system("@cls||clear");
                result=0;
                break;
            case 6:
                printf("\nDigite o n�mero correspondente ao valor n :");
                scanf("%d", &n);
                for(int i=1; i<=n;i++){
                   if(n%i==0){
                        printf("%d ", i);
                   }
                }
                printf("%d ",result);
                fflush(stdin);
                printf("\nDigite algo para continuar");
                getchar();
                system("@cls||clear");
                result=0;
                break;
            case 7:
                for(int i=1; i<=1000;i++){
                    if(i%3==0 ||i%5==0)
                        result+=i;
                }
                printf("%d ",result);
                fflush(stdin);
                printf("\nDigite algo para continuar");
                getchar();
                system("@cls||clear");
                result=0;
                break;
            case 8:
                printf("\nDigite inteiros positivos: ");
                scanf("%d", &number);
                min=number;
                while(number>=0){
                    scanf("%d", &number);
                    if(number<min){
                        min==number;
                    }
                    if(number>max){
                        max==number;
                    }
                }
                printf("O maior n�mero foi %d\nO menor n�mero foi %d",max,min);
                fflush(stdin);
                printf("\nDigite algo para continuar");
                getchar();
                system("@cls||clear");
                result=0;
                break;
            default:
                printf("Comando n�o reconhecido");
                fflush(stdin);
                printf("\nDigite algo para continuar");
                getchar();
                system("@cls||clear");
                result=0;
                break;

        }
        printf("Digite o n�mero do exerc�cio desejado (0 para encerrar): ");
        scanf("%d",&op);
    }
    printf("At� Logo");

}
