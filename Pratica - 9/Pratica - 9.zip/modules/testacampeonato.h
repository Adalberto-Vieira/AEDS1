#ifndef TESTACAMPEONATO_H
#define TESTACAMPEONATO_H
#include "jogo.h"

void rodaCampeonato(guerreiro *heighlander, int numberOfFighters);
int luta(guerreiro *p1, guerreiro *p2);
#endif
