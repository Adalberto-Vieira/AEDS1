#include <stdio.h>

int main(){
    int a;
    float b;
    char c;
    printf("A- %d\nB- %d\nC- %d",&a,&b,&c);
}
